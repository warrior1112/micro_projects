package com.example.e_buy;

import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccount extends AppCompatActivity {


    Button btn;
    DatabaseHelper db;
    TextView user, pass;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createaccount);

        db = new DatabaseHelper(this);
        addData();

    }

    public void addData() {
        user = (EditText) findViewById(R.id.e1);
        pass = (EditText) findViewById(R.id.e2);
        login = (Button) findViewById(R.id.b1);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    boolean in = db.insertData(user.getText().toString(), pass.getText().toString());
                    if (in == true) {
                        Toast.makeText(CreateAccount.this, "data inserted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(CreateAccount.this, "data not inserted!!!", Toast.LENGTH_LONG).show();
                    }
                }catch (SQLiteException e){
                    System.out.println(e.toString());
                }

            }
        });


    }
}
