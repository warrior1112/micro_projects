package com.example.e_buy;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String databaseName = "loginData.db";
    public static final String tableName = "loginData";
    public static final String col1 = "id";
    public static final String col2 = "username";
    public static final String col3 = "password";

    public DatabaseHelper(@Nullable Context context) {
        super(context, databaseName, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+tableName+ " (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)" );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+tableName);
        onCreate(db);
    }

    public boolean insertData(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(col2,username);
        contentValues.put(col3,password);
        long result = db.insert(tableName, null, contentValues);
        if(result==-1){
            return false;
        }
        else{
            return true;
        }
    }
}
