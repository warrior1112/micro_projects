package com.example.e_buy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.SystemClock;

import android.os.Bundle;

import android.database.sqlite.SQLiteDatabase;

public class SplashActivity extends AppCompatActivity {

DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        db = new DatabaseHelper(this);
        SystemClock.sleep(2200);
        Intent intent = new Intent(SplashActivity.this, Login.class);
        startActivity(intent);
        finish();
    }

}
