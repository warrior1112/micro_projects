package com.example.e_buy;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class Login extends AppCompatActivity {
    DatabaseHelper db;
    EditText user, pass;
    Button login,skip;
    TextView createacclink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        db = new DatabaseHelper(this);

        user = (EditText) findViewById(R.id.e1);
        pass = (EditText) findViewById(R.id.e2);
        login = (Button) findViewById(R.id.b1);
        skip = (Button) findViewById(R.id.b2);

        createacclink = (TextView) findViewById(R.id.createacclink);


        createacclink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), CreateAccount.class);
                startActivity(i);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase d = db.getWritableDatabase();
                Cursor rs = d.rawQuery("select * from loginData",null);
                while(rs.moveToNext()){
                    if(rs.getString(1).equals(user.getText().toString()) && rs.getString(2).equals(pass.getText().toString())){
                        Intent i = new Intent(v.getContext(), Home.class);
                        startActivity(i);
                }
    }
            }
        });

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), Home.class);
                startActivity(i);
            }
        });

    }







}